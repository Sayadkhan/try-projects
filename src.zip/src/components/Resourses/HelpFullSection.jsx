import React from "react";

const HelpFullSection = () => {
  return <div></div>;
};

export default HelpFullSection;
